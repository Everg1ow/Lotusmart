// Fill out your copyright notice in the Description page of Project Settings.

#include "CardReader.h"
#include "LotusCardDriver.h"
#include "MinWindows.h"

// Sets default values
ACardReader::ACardReader()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = false;

}

// Called when the game starts or when spawned
void ACardReader::BeginPlay()
{
	Super::BeginPlay();
	
}

// Called every frame
void ACardReader::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}

void ACardReader::OpenDevice(bool& bResult)
{
	hLotusCard = LotusCardOpenDevice("", 0, 0, 0, 0, NULL);
	bResult = (hLotusCard != -1);
}

void ACardReader::CloseDevice()
{
	if (hLotusCard != -1)
	{
		LotusCardCloseDevice(hLotusCard);
	}
}

void ACardReader::ReadIC(int Address, bool& bResult, TArray<uint8>& Data)
{
	if (hLotusCard != -1)
	{
		LotusCardParamStruct sttLotusCardParam;
		int nRequestType = RT_NOT_HALT;
		unsigned int nCardNo = 0;
		Data.SetNum(16);

		bResult = LotusCardSetCardType(hLotusCard, 'A');
		if (!bResult) {
			return;
		}

		// ִͬ��LotusCardRequest/LotusCardAnticoll/LotusCardSelect��������
		memset(&sttLotusCardParam, 0x00, sizeof(sttLotusCardParam));
		bResult = LotusCardGetCardNo(hLotusCard, nRequestType, &sttLotusCardParam);
		if (!bResult) {
			return;
		}
		memcpy(&nCardNo, sttLotusCardParam.arrCardNo, 4);

		//
		memset(&sttLotusCardParam.arrKeys, 0x00, sizeof(sttLotusCardParam.arrKeys));
		sttLotusCardParam.arrKeys[0] = 0xff;
		sttLotusCardParam.arrKeys[1] = 0xff;
		sttLotusCardParam.arrKeys[2] = 0xff;
		sttLotusCardParam.arrKeys[3] = 0xff;
		sttLotusCardParam.arrKeys[4] = 0xff;
		sttLotusCardParam.arrKeys[5] = 0xff;
		sttLotusCardParam.nKeysSize = 6;
		bResult = LotusCardLoadKey(hLotusCard, AM_A, 0, &sttLotusCardParam);
		if (!bResult) {
			return;
		}

		//
		bResult = LotusCardAuthentication(hLotusCard, AM_A, 0, &sttLotusCardParam);
		if (!bResult) {
			return;
		}

		//
		bResult = LotusCardRead(hLotusCard, Address, &sttLotusCardParam);
		if (!bResult) {
			return;
		}
		for (int i = 0; i < 16; i++) {
			Data[i] = sttLotusCardParam.arrBuffer[i];
		}

		return;
	}
}

void ACardReader::WriteIC(TArray<uint8> Data, int Address, bool& bResult)
{
	if (hLotusCard != -1)
	{
		LotusCardParamStruct sttLotusCardParam;
		int nRequestType = RT_NOT_HALT;
		unsigned int nCardNo = 0;

		bResult = LotusCardSetCardType(hLotusCard, 'A');
		if (!bResult) {
			return;
		}

		// ִͬ��LotusCardRequest/LotusCardAnticoll/LotusCardSelect��������
		memset(&sttLotusCardParam, 0x00, sizeof(sttLotusCardParam));
		bResult = LotusCardGetCardNo(hLotusCard, nRequestType, &sttLotusCardParam);
		if (!bResult) {
			return;
		}
		memcpy(&nCardNo, sttLotusCardParam.arrCardNo, 4);

		//
		memset(&sttLotusCardParam.arrKeys, 0x00, sizeof(sttLotusCardParam.arrKeys));
		sttLotusCardParam.arrKeys[0] = 0xff;
		sttLotusCardParam.arrKeys[1] = 0xff;
		sttLotusCardParam.arrKeys[2] = 0xff;
		sttLotusCardParam.arrKeys[3] = 0xff;
		sttLotusCardParam.arrKeys[4] = 0xff;
		sttLotusCardParam.arrKeys[5] = 0xff;
		sttLotusCardParam.nKeysSize = 6;
		bResult = LotusCardLoadKey(hLotusCard, AM_A, 0, &sttLotusCardParam);
		if (!bResult) {
			return;
		}

		//
		bResult = LotusCardAuthentication(hLotusCard, AM_A, 0, &sttLotusCardParam);
		if (!bResult) {
			return;
		}

		//
		memset(&sttLotusCardParam.arrBuffer, 0x00, sizeof(sttLotusCardParam.arrBuffer));
		for (int i = 0; i < Data.Num(); i++) {
			sttLotusCardParam.arrBuffer[i] = Data[i];
		}
		for (int j = Data.Num(); j < 16; j++) {
			sttLotusCardParam.arrBuffer[j] = 0x00;
		}
		sttLotusCardParam.nBufferSize = 16;
		bResult = LotusCardWrite(hLotusCard, Address, &sttLotusCardParam);
		if (!bResult) {
			return;
		}

		return;
	}
}

void ACardReader::Beep(int Duration, bool& bResult)
{
	if (hLotusCard != -1)
	{
		bResult = LotusCardBeep(hLotusCard, Duration);
	}
}

void ACardReader::ReadID(FString ServerIp, int UserAccount, FString Password, bool& bResult, FString& Name, FString& IdNo)
{
	if (hLotusCard != -1)
	{
		unsigned int nCardNo = 0;
		unsigned int unCyc = 0;
		char szTwoGenerationIdCardNo[64] = { 0 };
		wchar_t wstrTmp[256] = { 0 };
		char szErrorInfo[256] = { 0 };
		TwoIdInfoStruct sttTwoIdInfo;
		int nErrorCode = 0;

		memset(&sttTwoIdInfo, 0x00, sizeof(TwoIdInfoStruct));
		bResult = LotusCardSetCardType(hLotusCard, 'B');
		if (!bResult) {
			return;
		}
		bResult = LotusCardGetTwoGenerationIDCardNo(hLotusCard, szTwoGenerationIdCardNo, sizeof(szTwoGenerationIdCardNo));
		if (!bResult) {
			return;
		}
		//	bResult = LotusCardGetTwoIdInfoByServer(hLotusCard,"218.16.96.117",&sttTwoIdInfo);
		//bResult = LotusCardGetTwoIdInfoByMcuServer(hLotusCard, "119.29.18.30", 99999, "123456", &sttTwoIdInfo, 400000, 0, 2);
		bResult = LotusCardGetTwoIdInfoByMcuServer(hLotusCard, TCHAR_TO_ANSI(*ServerIp), UserAccount, TCHAR_TO_ANSI(*Password), &sttTwoIdInfo, 400000, 0, 2);
		//bResult = LotusCardGetTwoIdInfoByPsamServer(hLotusCard,"171.217.52.182",9292,&sttTwoIdInfo,2);
		if (!bResult) {
			nErrorCode = LotusCardGetTwoIdErrorCode(hLotusCard);
			LotusCardGetTwoIdErrorInfo(hLotusCard, (TwoIdErrorCode)nErrorCode, szErrorInfo, sizeof(szErrorInfo));
			return;
		}
		memset(&wstrTmp, 0x00, sizeof(wstrTmp));
		memcpy(&wstrTmp, &sttTwoIdInfo.arrTwoIdName, sizeof(sttTwoIdInfo.arrTwoIdName));

		//UnicodeתUTF-8
		int dwNum = WideCharToMultiByte(CP_UTF8, 0, wstrTmp, -1, NULL, 0, NULL, NULL);
		char *OutputUtf8 = (char*)malloc(dwNum + 1);
		memset(OutputUtf8, 0, dwNum + 1);
		WideCharToMultiByte(CP_UTF8, 0, wstrTmp, -1, OutputUtf8, dwNum, NULL, NULL);

		Name = FString(UTF8_TO_TCHAR(OutputUtf8));

		memset(&wstrTmp, 0x00, sizeof(wstrTmp));
		memcpy(&wstrTmp, &sttTwoIdInfo.arrTwoIdNo, sizeof(sttTwoIdInfo.arrTwoIdNo));

		//UnicodeתUTF-8
		dwNum = WideCharToMultiByte(CP_UTF8, 0, wstrTmp, -1, NULL, 0, NULL, NULL);
		OutputUtf8 = (char*)malloc(dwNum + 1);
		memset(OutputUtf8, 0, dwNum + 1);
		WideCharToMultiByte(CP_UTF8, 0, wstrTmp, -1, OutputUtf8, dwNum, NULL, NULL);

		IdNo = FString(UTF8_TO_TCHAR(OutputUtf8));

		//memset(&wstrTmp, 0x00, sizeof(wstrTmp));
		//memcpy(&wstrTmp, &sttTwoIdInfo.arrTwoIdAddress, sizeof(sttTwoIdInfo.arrTwoIdAddress));
		//strLog.Format(_T("��ַ %s"), wstrTmp);
		//AddLog(strLog);
		//memset(&wstrTmp, 0x00, sizeof(wstrTmp));
		//memcpy(&wstrTmp, &sttTwoIdInfo.arrTwoIdBirthday, sizeof(sttTwoIdInfo.arrTwoIdBirthday));
		//strLog.Format(_T("���� %s"), wstrTmp);
		//AddLog(strLog);
		/*memset(&wstrTmp, 0x00, sizeof(wstrTmp));
		memcpy(&wstrTmp, &sttTwoIdInfo.arrTwoIdNo, sizeof(sttTwoIdInfo.arrTwoIdNo));
		strLog.Format(_T("���� %s"), wstrTmp);*/
		return;
	}
}


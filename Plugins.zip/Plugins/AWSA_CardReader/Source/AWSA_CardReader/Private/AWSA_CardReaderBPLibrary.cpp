// Copyright 1998-2017 Epic Games, Inc. All Rights Reserved.

#include "AWSA_CardReaderBPLibrary.h"
#include "AWSA_CardReader.h"

UAWSA_CardReaderBPLibrary::UAWSA_CardReaderBPLibrary(const FObjectInitializer& ObjectInitializer)
: Super(ObjectInitializer)
{

}
// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "LotusCardDriver.h"
#include "CardReader.generated.h"

UCLASS()
class AWSA_CARDREADER_API ACardReader : public AActor
{
	GENERATED_BODY()
	
public:	
	// Sets default values for this actor's properties
	ACardReader();

protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;

public:	
	// Called every frame
	virtual void Tick(float DeltaTime) override;

	UFUNCTION(BlueprintCallable, meta = (DisplayName = "OpenDevice", Keywords = "AWSA_CardReader Open"), Category = "AWSA_CardReader")
		void OpenDevice(bool& bResult);

	UFUNCTION(BlueprintCallable, meta = (DisplayName = "CloseDevice", Keywords = "AWSA_CardReader Close"), Category = "AWSA_CardReader")
		void CloseDevice();

	UFUNCTION(BlueprintCallable, meta = (DisplayName = "ReadIC", Keywords = "AWSA_CardReader ReadIC"), Category = "AWSA_CardReader")
		void ReadIC(int Address, bool& bResult, TArray<uint8>& Data);

	UFUNCTION(BlueprintCallable, meta = (DisplayName = "WriteIC", Keywords = "AWSA_CardReader WriteIC"), Category = "AWSA_CardReader")
		void WriteIC(TArray<uint8> Data, int Address, bool& bResult);

	UFUNCTION(BlueprintCallable, meta = (DisplayName = "Beep", Keywords = "AWSA_CardReader Beep"), Category = "AWSA_CardReader")
		void Beep(int Duration, bool& bResult);

	UFUNCTION(BlueprintCallable, meta = (DisplayName = "ReadID", Keywords = "AWSA_CardReader ReadID"), Category = "AWSA_CardReader")
		void ReadID(FString ServerIp, int UserAccount, FString Password, bool& bResult, FString& Name, FString& IdNo);

	LotusHandle  hLotusCard;
	
};
